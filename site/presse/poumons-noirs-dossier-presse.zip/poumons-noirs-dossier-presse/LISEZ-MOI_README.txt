OPÉRATION POUMONS NOIRS / OPERATION BLACK LUNGS
Dossier presse / Press kit

FRANÇAIS

Opération Poumons Noirs est une application Android pour arrêter de fumer ou de vapoter, guidée par un sergent instructeur. Pas de félicitations pour rien : le Sergent Noclope donne un ordre vocal par jour pendant 365 jours, frappe aux moments où l'envie monte et ne lâche rien.

Le personnage : le Sergent Noclope, sergent instructeur au chapeau, moustache grise et sifflet, qui hurle sur les fumeurs pour leur bien.

Ce que fait l'appli
- 365 ordres du jour, lus par la voix du Sergent.
- SOS envie : trois minutes avec le Sergent, ou sur le mini-jeu Écrase-Clopes, pour tuer l'envie.
- Alertes aux moments critiques (café, pause, après le repas).
- Binôme : deux personnes arrêtent ensemble et voient la série de l'autre.
- Argent économisé, objectif à s'offrir, 27 trophées et 8 grades, widget d'écran d'accueil.
- Mode cigarette ou vapoteuse. En français et en anglais.

Disponibilité : en test fermé sur Google Play, sortie publique prochainement. Android uniquement.
Prix : 7 jours d'essai gratuits, puis paiement unique (49.90 CHF ou 49,99 €), ou abonnement à 9.90 CHF par mois ou 19.90 CHF par trimestre, résiliable à tout moment.
Public : adultes uniquement (18+). Langage cru assumé.
L'appli n'est pas un dispositif médical et ne remplace pas un avis médical.

Éditeur : Swiss Digital Studio, Krystel Fiorbianco, Valais, Suisse
Contact presse : contact@swissdigitalstudio.ch
Site : https://poumons-noirs.vercel.app

Les visuels, captures, vidéos et extraits audio de ce dossier peuvent être utilisés librement pour parler de l'appli.


ENGLISH

Operation Black Lungs is an Android app to quit smoking or vaping, led by a drill sergeant. No praise for nothing: Sergeant Noclope gives one voiced order a day for 365 days, strikes when cravings hit and never lets go.

The character: Sergeant Noclope, a campaign-hat drill sergeant with a grey mustache and a whistle, who yells at smokers for their own good.

What the app does
- 365 daily orders, read in the Sergeant's voice.
- Craving SOS: three minutes with the Sergeant, or on the Cig Crush mini-game, to kill the craving.
- Alerts at critical moments (coffee, breaks, after meals).
- Buddy mode: two people quit together and see each other's streak.
- Money saved, a goal to buy, 27 trophies and 8 ranks, home screen widget.
- Cigarette or vape mode. In English and French.

Availability: in closed testing on Google Play, public launch soon. Android only.
Price: 7-day free trial, then a one-time purchase, or a monthly or quarterly subscription you can cancel anytime. Prices are shown in local currency on Google Play.
Audience: adults only (18+). Crude language, on purpose.
The app is not a medical device and is not a substitute for medical advice.

Publisher: Swiss Digital Studio, Krystel Fiorbianco, Valais, Switzerland
Press contact: contact@swissdigitalstudio.ch
Website: https://poumons-noirs.vercel.app/en

The visuals, screenshots, videos and audio clips in this kit may be used freely to cover the app.


CONTENU / CONTENTS
- icone-512.png
- bannieres/ : banniere-fr et banniere-en (1024 x 500), reseaux-fr et reseaux-en (1200 x 630)
- captures-fr/ et captures-en/ : 7 captures (1080 x 1920)
- videos/ : deux vidéos verticales en français
- audio/ : extraits de la voix du Sergent
- personnage/ : le Sergent Noclope (image principale, fiche personnage, détourages PNG sur fond transparent)
